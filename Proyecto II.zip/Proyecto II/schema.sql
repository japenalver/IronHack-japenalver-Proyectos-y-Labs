use peliculas;

CREATE TABLE IF NOT EXISTS generos (
    id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pelicula (
    id INT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    release_date DATE,
    popularity DECIMAL(10,3),
    vote_average DECIMAL(3,1),
    vote_count INT,
    original_language VARCHAR(10),
    overview TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS genero_pelicula (
    id_pelicula INT,
    id_genero INT,
    PRIMARY KEY (id_pelicula, id_genero),
    FOREIGN KEY (id_pelicula) REFERENCES pelicula(id),
    FOREIGN KEY (id_genero) REFERENCES generos(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS personas (
    id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    gender TINYINT,
    birthday DATE,
    deathday DATE,
    place_of_birth VARCHAR(255),
    popularity DECIMAL(10,3),
    biography text,
    known_for_department varchar(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;personas

                        
CREATE TABLE IF NOT EXISTS cast (
    id_pelicula INT,
    id_persona INT,
	`character` VARCHAR(255),
    `order` INT,
    popularity  DECIMAL(10,3),
    PRIMARY KEY (id_pelicula, id_persona),
    FOREIGN KEY (id_pelicula) REFERENCES pelicula(id),
    FOREIGN KEY (id_persona) REFERENCES personas(id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;